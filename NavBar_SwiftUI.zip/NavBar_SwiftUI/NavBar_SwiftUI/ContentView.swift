//
//  ContentView.swift
//  NavBar_SwiftUI
//
//  Created by Immature Inc on 26/03/2020.
//  Copyright © 2020 AnthonyDesignCode. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            Form {
                VStack {
                    HStack {
                        Image(systemName: "person.fill")
                            .resizable()
                            .frame(width: 20, height: 20)
                            .padding()
                            .foregroundColor(.gray)
                        Text("Account")
                            .font(.headline)
                            .foregroundColor(.black)
                            .padding()
                        Spacer(minLength: 5)
                        Image(systemName: "chevron.right")
                            .resizable()
                            .frame(width: 10, height: 10)
                            .padding()
                            .foregroundColor(.gray)
                    }
                    HStack {
                        Image(systemName: "message.fill")
                            .resizable()
                            .frame(width: 20, height: 20)
                            .padding()
                            .foregroundColor(.gray)
                        Text("Chats")
                            .font(.headline)
                            .foregroundColor(.black)
                            .padding()
                        Spacer(minLength: 5)
                        Image(systemName: "1.circle.fill")
                            .resizable()
                            .frame(width: 20, height: 20)
                            .padding()
                            .foregroundColor(.green)
                        Image(systemName: "chevron.right")
                            .resizable()
                            .frame(width: 10, height: 10)
                            .padding()
                            .foregroundColor(.gray)
                    }
                    HStack {
                        Image(systemName: "bell.fill")
                            .resizable()
                            .frame(width: 20, height: 20)
                            .padding()
                            .foregroundColor(.gray)
                        Text("Notifications")
                            .font(.headline)
                            .foregroundColor(.black)
                            .padding()
                        Spacer(minLength: 5)
                        Image(systemName: "chevron.right")
                            .resizable()
                            .frame(width: 10, height: 10)
                            .padding()
                            .foregroundColor(.gray)
                    }
                }
                
                VStack {
                    HStack {
                        Image(systemName: "heart.fill")
                            .resizable()
                            .frame(width: 20, height: 20)
                            .padding()
                            .foregroundColor(.gray)
                        Text("Tell a Fiend")
                            .font(.headline)
                            .foregroundColor(.black)
                            .padding()
                        Spacer(minLength: 5)
                        Image(systemName: "chevron.right")
                            .resizable()
                            .frame(width: 10, height: 10)
                            .padding()
                            .foregroundColor(.gray)
                    }
                    HStack {
                        Image(systemName: "info")
                            .resizable()
                            .frame(width: 15, height: 15)
                            .padding()
                            .foregroundColor(.blue)
                        Text("Help")
                            .font(.headline)
                            .foregroundColor(.black)
                            .padding()
                        Spacer(minLength: 5)
                        Image(systemName: "chevron.right")
                            .resizable()
                            .frame(width: 10, height: 10)
                            .padding()
                            .foregroundColor(.gray)
                    }
                }
            }
            .navigationBarTitle("", displayMode: .inline)
            .navigationBarItems(leading:
                HStack {
                    Image(systemName: "line.horizontal.3")
                    .resizable()
                    .frame(width: 20, height: 20)
                    .padding()
                    Text("AppName")
                        .font(.title)
                        .bold()
                        .padding(60)
                }.foregroundColor(.white)
                , trailing:
                HStack {
                    Image(systemName: "magnifyingglass")
                        .resizable()
                        .frame(width: 20, height: 20)
                        .padding()
                    Spacer(minLength: 5)
                    Image(systemName: "person")
                        .resizable()
                        .frame(width: 20, height: 20)
                        .padding()
                
            }).foregroundColor(.white)
        }
    }
}

extension UINavigationController {
    override open func viewDidLoad() {
        super.viewDidLoad()
        
        let appearance = UINavigationBarAppearance()
        appearance.backgroundColor = .darkGray
        
        navigationBar.standardAppearance = appearance
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
